 <footer>
                <div class="footer" id="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 mg-tp-40 text-lcenter">
                            <img class="img-responsive" src="images/logo-merideando.png">
                            <ul class="social">
                                <li> <a href="https://www.facebook.com/pedro.sicilia.35"> <i class=" fa fa-facebook"> </i></a></li>
                                <li> <a href="https://twitter.com/PedroSici"> <i class="fa fa-twitter"> </i></a></li>
                                <li> <a href="https://www.instagram.com/pedro_sici/"> <i class="fa fa-instagram"> </i></a></li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 hidden-xs">
                            <h3> Merideando </h3>
                            <ul>
                                <li> <a href="index.php"> Inicio </a> </li>
                                <li> <a href="nosotros.php"> Nosotros</a></li>
                                <li> <a href="registro.php"> Regístrate </a> </li>
                                <li> <a href="index.php"> Contacto </a></li>
                                
                                
                            </ul>
                        </div>
                        <div class="col-lg-3  col-md-3 col-sm-3 hidden-xs">
                            <h3> Anuncios </h3>
                            <ul>
                                 <li> <a href="#"> Buscador </a></li>
                                <li> <a href="categorias.php"> Categorías </a></li>
                                <li> <a href="mapa_anuncios.php"> Mapa de anuncios </a></li>
                                <li> <a href="panel_usuario.php"> Panel Administración </a></li>
                                
                            </ul>
                        </div>
                        
                        <div class="col-lg-3  col-md-3 col-sm-3 col-xs-6 pull-right ">
                            <h3>Contacto </h3>
                            <ul>
                                <li><span class="fa-stack fa-lg">
                                      <i class="fa fa-circle fa-stack-2x"></i>
                                      <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                                    </span> C/ John Lennon, 36 
                                </li>
                                <li><span class="fa-stack fa-lg">
                                      <i class="fa fa-circle fa-stack-2x"></i>
                                      <i class="fa fa-phone fa-stack-1x fa-inverse"></i>
                                    </span> +34 645590102</li>
                               
                                <li><span class="fa-stack fa-lg">
                                      <i class="fa fa-circle fa-stack-2x"></i>
                                      <i class="fa fa-github fa-stack-1x fa-inverse"></i>
                                    </span> github/pedrosici</li>
                            </ul>
                            
                        </div>
                    </div>
                    <!--/.row--> 
                </div>
                <!--/.container--> 
            </div>
        <!--/.footer-->
        
            <div class="footer-bottom text-center">
                <div class="container">
                    <h5 class="copyright">Copyright © Merideando 2016. Todos los derechos reservados.</h5>
                </div>
            </div>
            <!--/.footer-bottom--> 
        </footer>